#include <iostream>

int main(){
	

	std::cout << "Hewwo..?" << std::endl;

	return 0;
}
